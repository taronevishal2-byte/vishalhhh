# JALSICHAL Dashboard
Original responsive frontend starter.

Open `index.html` in a browser. For GitHub Pages, upload `index.html`, `styles.css`, and `app.js` to the repository root.

This is frontend only. Real login, database, KYC upload, orders and admin panel require a backend.
