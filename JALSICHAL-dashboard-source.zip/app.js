const side=document.querySelector('#side'),shade=document.querySelector('#shade');
document.querySelector('#menu').onclick=()=>{side.classList.add('open');shade.classList.add('show')};
function close(){side.classList.remove('open');shade.classList.remove('show')}
document.querySelector('#close').onclick=close;shade.onclick=close;
const sets={mine:[['No. of orders','0','0','0'],['Order Value (₹)','0.00','0.00','0.00'],['Personal Business Volume','0','0','0']],group:[['Group orders','0','2','7'],['Group value (₹)','0.00','1,250.00','4,480.00'],['Group Business Volume','0','125','448']]};
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelector('#rows').innerHTML=sets[b.dataset.type].map(r=>'<tr>'+r.map(c=>'<td>'+c+'</td>').join('')+'</tr>').join('')});
document.querySelector('#photoBtn').onclick=()=>document.querySelector('#photo').click();
document.querySelector('#photo').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=x=>{const a=document.querySelector('.avatar');a.style.background='url('+x.target.result+') center/cover';a.textContent=''};r.readAsDataURL(f)};